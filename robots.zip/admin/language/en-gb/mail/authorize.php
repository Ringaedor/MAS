<?php
// Text
$_['text_subject'] = 'Security';
$_['text_code']    = 'You must enter the security code in the admin security check.';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';
