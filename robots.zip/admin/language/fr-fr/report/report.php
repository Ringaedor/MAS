<?php
// En-tête
$_['heading_title'] = 'Rapports';

// Texte
$_['text_success']  = 'Succès: Vous avez modifié les rapports!';
$_['text_type']     = 'Choisissez le type de rapport';
$_['text_filter']   = 'Filtrer';
