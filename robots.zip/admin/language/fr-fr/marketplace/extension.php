<?php
// En-tête
$_['heading_title'] = 'Extensions';

// Texte
$_['text_success']  = 'Succès: Vous avez modifié les extensions!';
$_['text_list']     = 'Liste des extensions';
$_['text_type']     = 'Choisissez le type d\'extension';
$_['text_filter']   = 'Filtrer';
