<?php
// Texte
$_['text_recommended'] = 'Recommandé';
$_['text_install']     = 'Installer';
$_['text_uninstall']   = 'Désinstaller';
$_['text_delete']      = 'Supprimer';
