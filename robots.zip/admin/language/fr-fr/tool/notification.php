<?php
// En-tête
$_['heading_title']    = 'Notifications';

// Texte
$_['text_success']     = 'Succès: Vous avez modifié les notifications!';
$_['text_list']        = 'Liste des notifications';

// Colonne
$_['column_message']   = 'Message';
$_['column_action']    = 'Action';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les notifications!';
